from .flightPrice_package import FlightPrice

FlightPrice('Sao paulo','Rio de janeiro','10/09/2023','10/10/2023').buscar_voos()