from .classes import Melhores_voos  

"""
    Arquivo de inicialização do pacote FlightPrice

    Autores: Alisson Rodrigo e Jorge Luis
"""

